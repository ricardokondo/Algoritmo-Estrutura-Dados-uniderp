#include <stdio.h>
#include <stdlib.h>

int troca(int *a, int *b);

int main(){
	int x = 10, y = 50;
	printf("Valor inicial: x = %d, y = %d", x, y);
	troca(&x, &y);
	printf("\nValor final: x = %d, y = %d", x, y);
	return 0;
}


int troca(int *a, int *b){
	int aux = *a;
	*a = *b;
	*b = aux;	
}
