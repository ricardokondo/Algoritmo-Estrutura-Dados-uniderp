#include <stdio.h>
#include <stdlib.h>

void mm(int v[], int n, int *min, int *max);

void mm(int v[], int n, int *min, int *max){
	int i;
	for(i = 0; i < n; i++){
		if(v[i] < *min){//verifica se elemento atual � menor que min
			*min = v[i];
		}
		if(v[i] > *max){//verifica se elemento atual � maior que max
			*max = v[i];
		}
	}
}

int main(){
	int n, i;
	int min, max;
	printf("Digite o tamanho do vetor: ");
	scanf("%d", &n);
	
	int v[n];
	
	for(i = 0; i < n; i++){
		printf("Digite o elemento v[%d]", i);
		scanf("%d", &v[i]);
	}
	
	mm(v, n, &min, &max);
	
	printf("O tamanho minimo desse vetor eh: %d\n", min);
	printf("O tamanho maximo desse vetor eh %d\n", max);
	return 0;
}
