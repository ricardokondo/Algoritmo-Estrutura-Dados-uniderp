#include <stdio.h>
#include <stdlib.h>

void hm(int mnts, int*h, int *m){
	*h = mnts/60;
	
	*m = mnts% 60;
}

int main(){
	int mnts, h, m;
	
	printf("Digite o numero de minutos: ");
	scanf("%d", &mnts);
	
	hm(mnts,&h,&m);
	
	printf("%d minutos equivalem a %d horas e %d minutos.\n", mnts, h, m);
	return 0;
}

