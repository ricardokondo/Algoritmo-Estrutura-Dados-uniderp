#include <stdio.h>

void trocar(int *x, int *y);

int main()
{
    int n1 = 0, n2 = 0;
    printf("Informe o primeiro numero: ");
    scanf("%d", &n1);
    printf("Informe o segundo numero: ");
    scanf("%d", &n2);
    printf("\nValor previo a troca: [1º]: %d; [2º]: %d", n1, n2);
    trocar(&n1, &n2);
    printf("\nValor apos a troca: [1º]: %d; [2º]: %d", n1, n2);
    return 0;
}

void trocar(int *x, int *y){
    int aux = 0;
    aux = *x;
    *x = *y;
    *y = aux;
}