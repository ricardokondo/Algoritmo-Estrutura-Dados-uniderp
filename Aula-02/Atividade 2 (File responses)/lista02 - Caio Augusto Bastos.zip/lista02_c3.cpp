//Leia dois n�meros inteiros.
//Crie dois ponteiros, um para cada n�mero, e calcule a soma utilizando exclusivamente os
//valores acessados pelos ponteiros.
#include <stdio.h>
#include <stdlib.h>

int troca(int *a, int *b);

int main(){
	int x = 0, y = 0, soma = 0;
	int *pt, *ptr;
	pt = &x;
	ptr = &y;
	printf("Informe o primeiro numero: ");
	scanf("%d", &x);
	printf("\nInforme o segundo numero: ");
	scanf("%d", &y);
	soma = *pt + *ptr;
	printf("Resultado da soma: %d", soma);
	return 0;
}

