/*12 - Escreva uma fun��o mm que receba um vetor inteiro v[0..n-1] e os endere�os de duas
vari�veis inteiras, digamos min e max, e deposite nessas vari�veis o valor de um elemento
m�nimo e o valor de um elemento m�ximo do vetor.
Escreva tamb�m uma fun��o main que use a fun��o mm.*/


