/*Um ponteiro pode ser usado para dizer a uma fun��o onde ela deve depositar o resultado de
seus c�lculos. Escreva uma fun��o hm que converta minutos em horas-e-minutos.
A fun��o recebe um inteiro mnts e os endere�os de duas vari�veis inteiras, digamos h e m, e
atribui valores a essas vari�veis de modo que m seja menor que 60 e que 60*h + m seja igual
a mnts.*/

#include <stdio.h>
#include <stdlib.h>

int converterMinutos(int mnts, int *h, int *m);

int main(){
	
	int minutos = 0;
	int h = 0;
	int m = 0;
	
	printf("Digite a quantidade de minutos que deseja converter: ");
	scanf("%d", &minutos);
	
	return 0;
}

int converterMinutos(int mnts, int *h, int *m){
	
	int conversao = 0;
	*h = mnts / 60;
	mnts = 60*h + m;
	
	
	return conversao;
}

