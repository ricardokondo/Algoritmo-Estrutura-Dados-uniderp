/*Declare uma vari�vel inteira com valor 25 e um ponteiro que armazene o endere�o dessa
vari�vel.
O programa dever� apresentar:
? o valor da vari�vel;
? o endere�o da vari�vel;
? o endere�o armazenado plo ponteiro;
? o valor acessado atrav�s do ponteiro.*/

#include <stdio.h>
#include <stdlib.h>

int main (){
	int x = 25;
	int *ptr;
	ptr = &x;
	printf ("Valor de X eh:%d ", x);
	printf ("\nO endereco de X eh:%d ", &x);
	printf ("\n========================\n");
	printf ("\nEndereco armazenado pelo ponteiro: %d", &ptr);
	printf ("\nValor acessado por intermedio do ponteiro: %d", *ptr);
	 
	return 0;
	
	
}
