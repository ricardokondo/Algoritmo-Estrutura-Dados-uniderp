/*Um ponteiro pode ser usado para dizer a uma fun��o onde ela deve depositar o resultado de
seus c�lculos. Escreva uma fun��o hm que converta minutos em horas-e-minutos.
A fun��o recebe um inteiro mnts e os endere�os de duas vari�veis inteiras, digamos h e m, e
atribui valores a essas vari�veis de modo que m seja menor que 60 e que 60*h + m seja igual
a mnts.
Escreva tamb�m uma fun��o main que use a fun��o hm.*/

#include <stdio.h>
#include <stdlib.h>

void hm (int min, int *p1, int *p2){
	*p1 = min / 60;
	*p2 = min % 60;
	
}

int main (){
	int minutos;
	int horas;
	int minRestantes;
	
	printf ("Digite a quantidade de minutos:\n");
	scanf ("%d", &minutos);
	
	hm (minutos, &horas, &minRestantes);
	printf ("====================================");
	printf ("%d Minutos eh igual a: \n", minutos);
	printf ("%d horas e %d minutos.\n", horas, minRestantes);
		
	return 0;
}

