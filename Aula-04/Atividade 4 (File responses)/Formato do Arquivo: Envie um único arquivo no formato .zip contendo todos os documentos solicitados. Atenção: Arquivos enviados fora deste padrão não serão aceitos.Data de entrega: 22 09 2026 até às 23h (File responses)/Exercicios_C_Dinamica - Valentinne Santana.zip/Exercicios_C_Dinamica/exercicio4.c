#include <stdio.h>
#include <stdlib.h>

int **criarMatriz(int linhas, int colunas) {
    int **M = (int **)malloc(linhas * sizeof(int *));

    if (M == NULL) {
        return NULL;
    }

    for (int i = 0; i < linhas; i++) {
        M[i] = (int *)malloc(colunas * sizeof(int));

        if (M[i] == NULL) {
            for (int j = 0; j < i; j++) {
                free(M[j]);
            }
            free(M);
            return NULL;
        }
    }

    return M;
}

void liberarMatriz(int **M, int linhas) {
    for (int i = 0; i < linhas; i++) {
        free(M[i]);
    }

    free(M);
}

int main() {
    int linhas, colunas;
    int **M;

    printf("Digite a quantidade de linhas: ");
    scanf("%d", &linhas);

    printf("Digite a quantidade de colunas: ");
    scanf("%d", &colunas);

    M = criarMatriz(linhas, colunas);

    if (M == NULL) {
        printf("Erro ao alocar memoria.\n");
        return 1;
    }

    printf("\nDigite os valores da matriz:\n");

    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            printf("M[%d][%d]: ", i, j);
            scanf("%d", &M[i][j]);
        }
    }

    printf("\nMatriz digitada:\n");

    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            printf("%d ", M[i][j]);
        }
        printf("\n");
    }

    liberarMatriz(M, linhas);

    return 0;
}
