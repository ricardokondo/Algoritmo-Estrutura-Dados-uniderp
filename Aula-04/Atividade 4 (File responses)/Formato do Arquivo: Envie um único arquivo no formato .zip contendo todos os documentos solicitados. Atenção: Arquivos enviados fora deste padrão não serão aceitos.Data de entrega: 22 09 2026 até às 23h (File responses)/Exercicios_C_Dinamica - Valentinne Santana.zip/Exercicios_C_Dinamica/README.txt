Exercicios de C - Alocacao Dinamica

Foram feitos os exercicios 1, 2, 4 e 5.
O exercicio 3 nao foi incluido, conforme solicitado.

Arquivos:
- exercicio1.c
- exercicio2.c
- exercicio4.c
- exercicio5.c
