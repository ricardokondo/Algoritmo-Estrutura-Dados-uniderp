#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char nome[50];
    float nota;
} Aluno;

int main() {
    int n;
    Aluno *alunos;
    int posicaoMaior = 0;

    printf("Digite a quantidade de alunos: ");
    scanf("%d", &n);

    alunos = (Aluno *)malloc(n * sizeof(Aluno));

    if (alunos == NULL) {
        printf("Erro ao alocar memoria.\n");
        return 1;
    }

    for (int i = 0; i < n; i++) {
        printf("\nDigite o nome do aluno %d: ", i + 1);
        scanf(" %49[^\n]", alunos[i].nome);

        printf("Digite a nota: ");
        scanf("%f", &alunos[i].nota);

        if (i == 0 || alunos[i].nota > alunos[posicaoMaior].nota) {
            posicaoMaior = i;
        }
    }

    printf("\nAluno com a maior nota:\n");
    printf("Nome: %s\n", alunos[posicaoMaior].nome);
    printf("Nota: %.2f\n", alunos[posicaoMaior].nota);

    free(alunos);

    return 0;
}
