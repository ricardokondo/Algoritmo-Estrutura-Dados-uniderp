#include <stdio.h>
#include <stdlib.h>

int main() {
    int n;
    float *notas;
    float soma = 0, media;

    printf("Digite a quantidade de notas: ");
    scanf("%d", &n);

    notas = (float *)malloc(n * sizeof(float));

    if (notas == NULL) {
        printf("Erro ao alocar memoria.\n");
        return 1;
    }

    for (int i = 0; i < n; i++) {
        printf("Digite a nota %d: ", i + 1);
        scanf("%f", &notas[i]);
        soma += notas[i];
    }

    media = soma / n;

    printf("\nMedia: %.2f\n", media);
    printf("Notas acima da media:\n");

    for (int i = 0; i < n; i++) {
        if (notas[i] > media) {
            printf("%.2f\n", notas[i]);
        }
    }

    free(notas);

    return 0;
}
