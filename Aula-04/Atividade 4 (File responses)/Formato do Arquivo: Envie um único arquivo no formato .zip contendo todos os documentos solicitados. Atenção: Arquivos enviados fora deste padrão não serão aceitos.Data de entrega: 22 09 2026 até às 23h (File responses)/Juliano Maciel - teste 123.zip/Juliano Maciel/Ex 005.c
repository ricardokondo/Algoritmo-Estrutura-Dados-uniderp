#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char nome[50];
    float nota;
} Aluno;

int main() {
    Aluno *alunos;
    int n, i, maior;

    printf("Digite a quantidade de alunos: ");
    scanf("%d", &n);

    alunos = (Aluno *) malloc(n * sizeof(Aluno));

    if (alunos == NULL) {
        printf("Erro ao alocar memoria.\n");
        return 1;
    }

    for (i = 0; i < n; i++) {
        printf("\nNome do aluno: ");
        scanf(" %49[^\n]", alunos[i].nome);

        printf("Nota: ");
        scanf("%f", &alunos[i].nota);
    }

    maior = 0;

    for (i = 1; i < n; i++) {
        if (alunos[i].nota > alunos[maior].nota) {
            maior = i;
        }
    }

    printf("\nAluno com a maior nota: %s\n", alunos[maior].nome);
    printf("Nota: %.2f\n", alunos[maior].nota);

    free(alunos);

    return 0;
}1
