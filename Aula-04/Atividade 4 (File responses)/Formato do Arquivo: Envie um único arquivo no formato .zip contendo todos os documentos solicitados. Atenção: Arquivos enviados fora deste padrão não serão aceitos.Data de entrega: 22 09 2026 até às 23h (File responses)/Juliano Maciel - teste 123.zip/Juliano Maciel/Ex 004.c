#include <stdio.h>
#include <stdlib.h>

int **criarMatriz(int linhas, int colunas) {
    int **M;
    int i, j;

    M = (int **) malloc(linhas * sizeof(int *));

    if (M == NULL) {
        return NULL;
    }

    for (i = 0; i < linhas; i++) {
        M[i] = (int *) malloc(colunas * sizeof(int));

        if (M[i] == NULL) {
            for (j = 0; j < i; j++) {
                free(M[j]);
            }

            free(M);
            return NULL;
        }
    }

    return M;
}

void liberarMatriz(int **M, int linhas) {
    int i;

    for (i = 0; i < linhas; i++) {
        free(M[i]);
    }

    free(M);
}

int main() {
    int linhas, colunas;
    int i, j;
    int **matriz;

    printf("Digite a quantidade de linhas: ");
    scanf("%d", &linhas);

    printf("Digite a quantidade de colunas: ");
    scanf("%d", &colunas);

    if (linhas <= 0 || colunas <= 0) {
        printf("Tamanho invalido.\n");
        return 1;
    }

    matriz = criarMatriz(linhas, colunas);

    if (matriz == NULL) {
        printf("Erro ao alocar memoria.\n");
        return 1;
    }

    printf("\nDigite os valores da matriz:\n");

    for (i = 0; i < linhas; i++) {
        for (j = 0; j < colunas; j++) {
            printf("M[%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);
        }
    }

    printf("\nMatriz:\n");

    for (i = 0; i < linhas; i++) {
        for (j = 0; j < colunas; j++) {
            printf("%d\t", matriz[i][j]);
        }

        printf("\n");
    }

    liberarMatriz(matriz, linhas);

    return 0;
}
