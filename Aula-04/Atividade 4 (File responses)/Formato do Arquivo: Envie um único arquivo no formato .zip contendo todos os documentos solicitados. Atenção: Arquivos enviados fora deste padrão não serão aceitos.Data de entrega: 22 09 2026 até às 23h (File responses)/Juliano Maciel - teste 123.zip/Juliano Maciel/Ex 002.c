#include <stdio.h>
#include <stdlib.h>

int main() {
    int n;
    float *vetor;
    float maior, menor;
	int i;
    printf("Digite a quantidade de numeros: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Quantidade invalida.\n");
        return 1;
    }

    vetor = (float *) malloc(n * sizeof(float));

    if (vetor == NULL) {
        printf("Erro ao alocar memoria.\n");
        return 1;
    }


    for (i = 0; i < n; i++) {
        printf("Digite o valor %d: ", i + 1);
        scanf("%f", &vetor[i]);
    }

    maior = vetor[0];
    menor = vetor[0];

    for (i = 1; i < n; i++) {

        if (vetor[i] > maior) {
            maior = vetor[i];
        }

        if (vetor[i] < menor) {
            menor = vetor[i];
        }
    }

    printf("\nMaior valor: %.2f\n", maior);
    printf("Menor valor: %.2f\n", menor);

    free(vetor);

    return 0;
}
