#include <stdio.h>
#include <stdlib.h>

void criarVetorDinamico();

void apresentarMaiorEMenor(float *v, int n);

void criarVetorDinamico(){
	int n;
	float *v; 
    
    printf("Informe a quantidade de numeros que deseja adicionar: ");
    scanf("%d", &n);
    
    v = (float *)malloc(n * sizeof(float));
   
	for(int i = 0; i < n; i++){
		printf("Informe o valor de v[%d]: ", i);
		scanf("%f", &v[i]);
	}
	apresentarMaiorEMenor(v, n);
	free(v);
}

void apresentarMaiorEMenor(float *v, int n){
    float maior = v[0], menor = v[0];
	for (int y = 0; y < n; y++){
	    if(maior < v[y]){
	        maior = v[y];
	    } 
	    if (menor > v[y]){
	        menor = v[y];
	    }
	}
	printf(" O maior numero da lista eh: %.2f \n O menor numero da lista eh: %.2f", maior, menor);
}

int main()
{
    criarVetorDinamico();
    return 0;
}
