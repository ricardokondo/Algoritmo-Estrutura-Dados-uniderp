#include <stdio.h>
#include <stdlib.h>

int **criarEMostrarMatriz(int linhas, int colunas);
void liberarMatriz(int **M, int linhas);

int main()
{
    int linhas, colunas; 
    int **M; 
    printf("Informe a quantidade de linhas: ");
    scanf("%d", &linhas);
    
    printf("Informe a quantidade de colunas: ");
    scanf("%d", &colunas);
    liberarMatriz(criarEMostrarMatriz(linhas, colunas), linhas);
    return 0;
}


int **criarEMostrarMatriz(int linhas, int colunas){
    int **M;
    M = (int **)malloc(linhas * sizeof(int *));
    
    
    for(int x = 0; x < linhas; x++){
        M[x] = (int *)malloc(colunas * sizeof(int));
    }
        
    for(int y = 0; y < linhas; y++){
        for(int z = 0; z < colunas; z++){
            printf("Informe o valor para o indice V[%d][%d]: ", y, z);
            scanf("%d", &M[y][z]);
        }
    }
    for(int j = 0; j < linhas; j++){
        for(int k = 0; k < colunas; k++){
            printf("Matriz[%d][%d]: %d\n", j, k, M[j][k]);
        }
    }
    return M; 
}

void liberarMatriz(int **M, int linhas){
    for(int g = 0; g < linhas; g++){
        free(M[g]);
    }
    free(M);
} 