#include <stdio.h>
#include <stdlib.h>

void manipularNotas();
float calcularMedia(float v[], int n);
void mostrarNotasSuperiores(float v[], int n,float media);

void manipularNotas(){
	int n;
    float *v;
    float media = 0;
    
    printf("Informe a quantidade de notas que se deseja ler: ");
    scanf("%d", &n);
    
    v = (float *)malloc(n * sizeof(float));
   
	for(int i = 0; i < n; i++){
		printf("Informe o valor de v[%d]: ", i);
		scanf("%f", &v[i]);
	}
	
	media = calcularMedia(v, n);
	mostrarNotasSuperiores(v, n, media);
	
	free(v);
}

float calcularMedia(float v[],int n){
	float mediaf = 0;
	for(int x = 0; x < n; x++){
		mediaf += v[x];
	}
	mediaf /= n;
	return mediaf;
}

void mostrarNotasSuperiores(float v[],int n,float media){
	for (int y = 0; y < n; y++){
		if(v[y] > media){
			printf("A nota v[%d]: %.2f eh superior a media.\n", y, v[y]);
		}
	}
}

int main()
{
    manipularNotas();
    return 0;
}
