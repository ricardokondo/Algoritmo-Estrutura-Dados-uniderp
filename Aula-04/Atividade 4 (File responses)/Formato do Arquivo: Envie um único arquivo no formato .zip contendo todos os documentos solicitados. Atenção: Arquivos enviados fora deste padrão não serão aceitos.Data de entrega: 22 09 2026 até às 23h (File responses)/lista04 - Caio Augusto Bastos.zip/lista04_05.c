#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char nome[50];
    float nota;
} Aluno;

void verificarMaiorNota(int numAl);
void limpeza();

int main()
{
    int numAl;
    printf("Informe a quantidade de alunos que deseja cadastrar: ");
    scanf("%d", &numAl);
    limpeza();
    verificarMaiorNota(numAl);
    return 0;
}

void verificarMaiorNota(int numAl){
    Aluno *aluno;
    aluno = (Aluno *)malloc(numAl * sizeof(Aluno));
    for(int x = 0; x < numAl; x++){
        printf("Informe os dados do aluno de índice v[%d]", x);
        printf("\nNome: ");
        fgets(aluno[x].nome, 50, stdin);
        aluno[x].nome[strcspn(aluno[x].nome, "\n")] = '\0';
        printf("\nNota: ");
        scanf("%f", &aluno[x].nota);
        limpeza();
    }
    int idMaior = 0; 
    float teste = aluno[0].nota; 
    for(int x = 1; x < numAl; x++){
        if(teste < aluno[x].nota){
            teste = aluno[x].nota;
            idMaior = x;
        }
    }
    printf("--- Dados do aluno ---");
    printf("\n\nNome: %s\nNota: %.2f", aluno[idMaior].nome, aluno[idMaior].nota);
    
}

void limpeza(){
    int limpe = 0;
    while((limpe = getchar()) != '\n' && limpe != EOF) {}
    return; 
}