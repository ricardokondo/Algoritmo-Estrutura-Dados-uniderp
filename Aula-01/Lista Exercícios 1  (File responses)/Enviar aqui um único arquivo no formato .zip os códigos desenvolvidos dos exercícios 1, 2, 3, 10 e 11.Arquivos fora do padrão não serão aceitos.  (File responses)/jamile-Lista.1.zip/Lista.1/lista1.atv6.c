#include <iostream>
using namespace std;

int main() {
    for (int i = 1; i <= 10; ++i) cout << i << (i == 10 ? '\n' : ' ');
    return 0;
}
